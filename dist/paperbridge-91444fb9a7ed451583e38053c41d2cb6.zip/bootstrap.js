var PaperBridge;

function paperbridgeLog(message) {
  Zotero.debug(`PaperBridge: ${message}`);
}

async function startup({ id, version, rootURI }) {
  paperbridgeLog(`Starting ${version}`);

  const scripts = [
    "chrome/content/modules/constants.js",
    "chrome/content/modules/settings.js",
    "chrome/content/modules/util.js",
    "chrome/content/modules/index.js",
    "chrome/content/modules/ranks.js",
    "chrome/content/modules/notes.js",
    "chrome/content/modules/bulk.js",
    "chrome/content/modules/deleteQueue.js",
    "chrome/content/modules/columns.js",
    "chrome/content/modules/menus.js",
    "chrome/content/modules/shortcuts.js",
    "chrome/content/modules/notifications.js",
    "chrome/content/modules/ui.js",
    "chrome/content/paperbridge.js"
  ];

  for (const script of scripts) {
    Services.scriptloader.loadSubScript(rootURI + script, this);
  }

  PaperBridge.init({ id, version, rootURI });

  await Zotero.PreferencePanes.register({
    pluginID: id,
    src: rootURI + "preferences.xhtml",
    scripts: [rootURI + "preferences.js"],
    stylesheets: [rootURI + "style.css"]
  });

  await PaperBridge.start();
  PaperBridge.addToAllWindows();
}

function onMainWindowLoad({ window }) {
  PaperBridge?.addToWindow(window);
}

function onMainWindowUnload({ window }) {
  PaperBridge?.removeFromWindow(window);
}

async function shutdown() {
  paperbridgeLog("Shutting down");
  await PaperBridge?.stop();
  PaperBridge?.removeFromAllWindows();
  PaperBridge = undefined;
}

function install() {
  paperbridgeLog("Installed");
}

function uninstall() {
  paperbridgeLog("Uninstalled");
}
