PaperBridge = PaperBridge || {};

PaperBridge.Notifications = {
  observerID: null,
  timers: new Map(),
  pending: new Map(),
  retryCounts: new Map(),
  retryDelay: 5000,
  maxRetries: 5,

  start() {
    if (this.observerID) {
      return;
    }
    this.observerID = Zotero.Notifier.registerObserver(this.observer, ["item", "collection-item"]);
  },

  stop() {
    if (this.observerID) {
      Zotero.Notifier.unregisterObserver(this.observerID);
      this.observerID = null;
    }
    for (const timer of this.timers.values()) {
      clearTimeout(timer);
    }
    this.timers.clear();
    this.pending.clear();
    this.retryCounts.clear();
  },

  observer: {
    notify: (event, type, ids, extraData) => {
      PaperBridge.Notifications.notify(event, type, ids, extraData);
    }
  },

  notify(event, type, ids, extraData) {
    if (!PaperBridge.Settings.getBool("autoCreate", true)) {
      return;
    }

    if (type === "item" && (event === "add" || event === "modify")) {
      for (const id of ids) {
        this.scheduleItem(id);
      }
    }

    if (type === "collection-item" && event === "add") {
      for (const entry of this.extractCollectionItemEvents(ids, extraData)) {
        this.scheduleItem(entry.itemID, entry.collectionID);
      }
    }
  },

  scheduleItem(itemID, collectionID = null, delay = 3000) {
    const numericID = Number(itemID);
    if (!Number.isFinite(numericID)) {
      return;
    }
    clearTimeout(this.timers.get(numericID));
    const existing = this.pending.get(numericID) || {};
    const numericCollectionID = Number(collectionID);
    const nextCollectionID = Number.isFinite(numericCollectionID)
      ? numericCollectionID
      : existing.collectionID || null;
    this.pending.set(numericID, { collectionID: nextCollectionID });

    const timer = setTimeout(() => {
      this.timers.delete(numericID);
      const pending = this.pending.get(numericID) || {};
      this.pending.delete(numericID);
      this.tryAutoCreate(numericID, pending.collectionID).catch(error => PaperBridge.Util.logError(error));
    }, delay);
    this.timers.set(numericID, timer);
  },

  async tryAutoCreate(itemID, collectionID = null) {
    const item = Zotero.Items.get(itemID);
    if (!item || !PaperBridge.Notes.isRegularItem(item) || item.deleted) {
      return;
    }
    const collectionIDs = typeof item.getCollections === "function" ? item.getCollections() : [];
    if (!collectionIDs.length) {
      return;
    }
    if (!PaperBridge.Notes.hasMinimumMetadata(item)) {
      this.retryItem(itemID, collectionID);
      return;
    }

    const state = PaperBridge.Notes.getNoteState(item);
    if (state !== PaperBridge.Constants.noteStates.create) {
      return;
    }
    await PaperBridge.Notes.createNoteForItem(item, {
      collection: this.collectionForItem(item, collectionID)
    });
    this.retryCounts.delete(itemID);
  },

  retryItem(itemID, collectionID) {
    const retries = (this.retryCounts.get(itemID) || 0) + 1;
    if (retries > this.maxRetries) {
      PaperBridge.Util.log(`Skipping auto-create for item ${itemID}; title is still missing after retries.`);
      this.retryCounts.delete(itemID);
      return;
    }
    this.retryCounts.set(itemID, retries);
    this.scheduleItem(itemID, collectionID, this.retryDelay);
  },

  collectionForItem(item, collectionID) {
    const collection = PaperBridge.Notes.resolveCollection(collectionID);
    const itemCollectionIDs = typeof item.getCollections === "function" ? item.getCollections() : [];
    if (collection && itemCollectionIDs.includes(collection.id)) {
      return collection;
    }
    return null;
  },

  extractCollectionItemEvents(ids, extraData) {
    const found = new Map();
    for (const value of Object.values(extraData || {})) {
      const itemID = value?.itemID || value?.item?.id || value?.id;
      const collectionID = value?.collectionID || value?.collection?.id;
      if (Number.isFinite(Number(itemID))) {
        found.set(Number(itemID), {
          itemID: Number(itemID),
          collectionID: Number.isFinite(Number(collectionID)) ? Number(collectionID) : null
        });
      }
    }

    for (const id of ids || []) {
      const parsed = this.collectionItemFromNotifierID(id);
      if (parsed?.itemID && Zotero.Items.get(parsed.itemID)) {
        found.set(parsed.itemID, parsed);
      }
    }
    return [...found.values()];
  },

  collectionItemFromNotifierID(id) {
    const numbers = String(id).match(/\d+/g)?.map(Number) || [];
    if (!numbers.length) {
      return null;
    }

    if (numbers.length >= 2) {
      const candidates = [
        { collectionID: numbers[0], itemID: numbers[numbers.length - 1] },
        { collectionID: numbers[numbers.length - 1], itemID: numbers[0] }
      ];
      for (const candidate of candidates) {
        if (Zotero.Items.get(candidate.itemID) && PaperBridge.Notes.resolveCollection(candidate.collectionID)) {
          return candidate;
        }
      }
    }

    return {
      itemID: numbers[numbers.length - 1],
      collectionID: null
    };
  }
};
