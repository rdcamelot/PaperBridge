PaperBridge = PaperBridge || {};

PaperBridge.Menus = {
  addedElementIDs: new Map(),

  addToWindow(window) {
    if (this.addedElementIDs.has(window)) {
      return;
    }

    const doc = window.document;
    const ids = [];
    const toolsPopup = doc.getElementById("menu_ToolsPopup") || doc.getElementById("menu_toolsPopup");
    if (!toolsPopup) {
      this.addedElementIDs.set(window, ids);
      return;
    }

    this.addMenuItem(doc, toolsPopup, ids, {
      id: "paperbridge-create-notes-selected",
      label: "PaperBridge: 为选中条目创建笔记",
      command: () => {
        PaperBridge.Bulk.createNotesForSelected().catch(error => {
          PaperBridge.Util.logError(error);
          PaperBridge.Util.alert(error.message);
        });
      }
    });

    this.addMenuItem(doc, toolsPopup, ids, {
      id: "paperbridge-create-notes-collection",
      label: "PaperBridge: 为当前分类创建笔记",
      command: () => {
        PaperBridge.Bulk.createNotesForCurrentCollection().catch(error => {
          PaperBridge.Util.logError(error);
          PaperBridge.Util.alert(error.message);
        });
      }
    });

    this.addMenuItem(doc, toolsPopup, ids, {
      id: "paperbridge-clean-x-items",
      label: "PaperBridge: 清理 x",
      command: () => {
      PaperBridge.DeleteQueue.cleanRankedItems().catch(error => {
        PaperBridge.Util.logError(error);
        PaperBridge.Util.alert(error.message);
      });
      }
    });

    this.addedElementIDs.set(window, ids);
  },

  addMenuItem(doc, parent, ids, { id, label, command }) {
    const item = doc.createXULElement("menuitem");
    item.id = id;
    item.setAttribute("label", label);
    item.addEventListener("command", command);
    parent.appendChild(item);
    ids.push(item.id);
    return item;
  },

  removeFromWindow(window) {
    const ids = this.addedElementIDs.get(window) || [];
    for (const id of ids) {
      window.document.getElementById(id)?.remove();
    }
    this.addedElementIDs.delete(window);
  },

  removeFromAllWindows() {
    for (const window of [...this.addedElementIDs.keys()]) {
      this.removeFromWindow(window);
    }
  }
};
