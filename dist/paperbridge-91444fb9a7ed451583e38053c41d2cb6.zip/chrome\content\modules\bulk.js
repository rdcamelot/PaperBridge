PaperBridge = PaperBridge || {};

PaperBridge.Bulk = {
  async createNotesForSelected() {
    const items = PaperBridge.Util.getSelectedRegularItems();
    if (!items.length) {
      PaperBridge.Util.alert("No regular Zotero items are selected.");
      return;
    }

    const result = await this.createNotesForItems(items, {
      collection: PaperBridge.Util.getSelectedCollection()
    });
    this.showResult(result);
  },

  async createNotesForCurrentCollection() {
    const collection = PaperBridge.Util.getSelectedCollection();
    if (!collection) {
      PaperBridge.Util.alert("Select a Zotero collection first.");
      return;
    }

    const items = this.regularItemsFromCollection(collection);
    if (!items.length) {
      PaperBridge.Util.alert("The selected collection has no regular Zotero items.");
      return;
    }

    const ok = PaperBridge.Util.confirm(
      `Create or relink Markdown notes for ${items.length} item(s) in "${collection.name}"?`
    );
    if (!ok) {
      return;
    }

    const result = await this.createNotesForItems(items, { collection });
    this.showResult(result);
  },

  regularItemsFromCollection(collection) {
    const childItems = collection.getChildItems?.() || [];
    return childItems.filter(item => item && PaperBridge.Notes.isRegularItem(item) && !item.deleted);
  },

  async createNotesForItems(items, options = {}) {
    const seen = new Set();
    const result = {
      total: 0,
      created: 0,
      alreadyReady: 0,
      failed: 0
    };

    for (const item of items) {
      if (!item || seen.has(item.id) || !PaperBridge.Notes.isRegularItem(item) || item.deleted) {
        continue;
      }
      seen.add(item.id);
      result.total++;

      try {
        const state = PaperBridge.Notes.getNoteState(item);
        await PaperBridge.Notes.createNoteForItem(item, options);
        if (state === PaperBridge.Constants.noteStates.ready) {
          result.alreadyReady++;
        }
        else {
          result.created++;
        }
      }
      catch (error) {
        result.failed++;
        PaperBridge.Util.logError(error);
      }
    }

    Zotero.ItemTreeManager.refreshColumns();
    return result;
  },

  showResult(result) {
    PaperBridge.Util.alert(
      `Processed ${result.total} item(s).\n` +
      `Created/relinked: ${result.created}\n` +
      `Already ready: ${result.alreadyReady}\n` +
      `Failed: ${result.failed}`
    );
  }
};
