PaperBridge = PaperBridge || {};

PaperBridge.Util = {
  log(message) {
    Zotero.debug(`PaperBridge: ${message}`);
  },

  logError(error) {
    Zotero.logError(error);
  },

  alert(message, title = "PaperBridge") {
    Services.prompt.alert(null, title, message);
  },

  confirm(message, title = "PaperBridge") {
    return Services.prompt.confirm(null, title, message);
  },

  todayISO() {
    return new Date().toISOString().slice(0, 10);
  },

  pathJoin(...segments) {
    const clean = segments.filter(segment => segment !== undefined && segment !== null && String(segment).length);
    return PathUtils.join(...clean.map(segment => String(segment)));
  },

  sanitizePathSegment(value, fallback = "Untitled") {
    const sanitized = String(value || "")
      .replace(/[<>:"/\\|?*\u0000-\u001f]/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/[. ]+$/g, "");
    return sanitized || fallback;
  },

  truncateFilename(filename, maxLength) {
    if (!maxLength || filename.length <= maxLength) {
      return filename;
    }
    const extIndex = filename.lastIndexOf(".");
    const ext = extIndex > 0 ? filename.slice(extIndex) : "";
    const stem = extIndex > 0 ? filename.slice(0, extIndex) : filename;
    const room = Math.max(24, maxLength - ext.length);
    return `${stem.slice(0, room).trim()}${ext}`;
  },

  yamlString(value) {
    if (value === undefined || value === null || value === "") {
      return "";
    }
    return `"${String(value)
      .replace(/\\/g, "\\\\")
      .replace(/"/g, '\\"')
      .replace(/\r?\n/g, " ")}"`;
  },

  pathExistsSync(path) {
    if (!path) {
      return false;
    }
    try {
      return Zotero.File.pathToFile(path).exists();
    }
    catch (error) {
      return false;
    }
  },

  async ensureDirectory(path) {
    await IOUtils.makeDirectory(path, { createAncestors: true, ignoreExisting: true });
  },

  async uniquePath(directory, filename) {
    let candidate = this.pathJoin(directory, filename);
    if (!(await IOUtils.exists(candidate))) {
      return candidate;
    }

    const dot = filename.lastIndexOf(".");
    const stem = dot > 0 ? filename.slice(0, dot) : filename;
    const ext = dot > 0 ? filename.slice(dot) : "";
    for (let i = 2; i < 1000; i++) {
      candidate = this.pathJoin(directory, `${stem} (${i})${ext}`);
      if (!(await IOUtils.exists(candidate))) {
        return candidate;
      }
    }
    throw new Error(`Cannot find an available filename for ${filename}`);
  },

  libraryURIPath(item) {
    if (item.libraryID === Zotero.Libraries.userLibraryID) {
      return "library";
    }
    const library = Zotero.Libraries.get(item.libraryID);
    if (library?.libraryType === "group" && library.groupID) {
      return `groups/${library.groupID}`;
    }
    return "library";
  },

  zoteroSelectURI(item) {
    return `zotero://select/${this.libraryURIPath(item)}/items/${item.key}`;
  },

  zoteroPDFURI(attachment) {
    if (!attachment) {
      return "";
    }
    return `zotero://open-pdf/${this.libraryURIPath(attachment)}/items/${attachment.key}`;
  },

  getActivePane() {
    try {
      return Zotero.getActiveZoteroPane?.() || null;
    }
    catch (error) {
      return null;
    }
  },

  getSelectedRegularItems() {
    const pane = this.getActivePane();
    const selected = pane?.getSelectedItems?.() || [];
    return selected.filter(item => item && PaperBridge.Notes.isRegularItem(item));
  },

  getSelectedCollection() {
    try {
      return this.getActivePane()?.getSelectedCollection?.() || null;
    }
    catch (error) {
      return null;
    }
  },

  getSelectedLibraryID() {
    try {
      const pane = this.getActivePane();
      const libraryID = pane?.getSelectedLibraryID?.();
      return Number.isFinite(Number(libraryID)) ? Number(libraryID) : null;
    }
    catch (error) {
      return null;
    }
  },

  runProcess(executablePath, args, blocking = true) {
    const file = Zotero.File.pathToFile(executablePath);
    const process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
    process.init(file);
    process.run(blocking, args, args.length);
  }
};
