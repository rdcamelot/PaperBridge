PaperBridge = PaperBridge || {};

PaperBridge.Columns = {
  registeredKeys: [],

  async register() {
    if (!Zotero.ItemTreeManager?.registerColumn) {
      PaperBridge.Util.log("Zotero.ItemTreeManager.registerColumn is unavailable.");
      return;
    }

    this.registeredKeys.push(await Zotero.ItemTreeManager.registerColumn({
      dataKey: "paperbridge-note",
      label: "笔记",
      pluginID: PaperBridge.id,
      enabledTreeIDs: ["main"],
      width: "48",
      fixedWidth: true,
      staticWidth: true,
      minWidth: 36,
      dataProvider: item => PaperBridge.Notes.getNoteCellData(item),
      renderCell: (index, data, column, isFirstColumn, doc) => this.renderNoteCell(data, doc),
      zoteroPersist: ["width", "hidden"]
    }));

    this.registeredKeys.push(await Zotero.ItemTreeManager.registerColumn({
      dataKey: "paperbridge-rank",
      label: "等级",
      pluginID: PaperBridge.id,
      enabledTreeIDs: ["main"],
      width: "48",
      fixedWidth: true,
      staticWidth: true,
      minWidth: 36,
      dataProvider: item => `${item.id}|${PaperBridge.Ranks.getRank(item)}`,
      renderCell: (index, data, column, isFirstColumn, doc) => this.renderRankCell(data, doc),
      zoteroPersist: ["width", "hidden", "sortDirection"]
    }));
  },

  async unregister() {
    for (const key of this.registeredKeys.filter(Boolean)) {
      await Zotero.ItemTreeManager.unregisterColumn(key);
    }
    this.registeredKeys = [];
  },

  renderNoteCell(data, doc) {
    const [itemID, state] = String(data || "").split("|");
    const cell = doc.createElement("span");
    cell.className = `paperbridge-cell paperbridge-cell-action ${state === "!" ? "paperbridge-note-missing" : ""}`;
    cell.textContent = state || "";
    cell.title = this.noteTitle(state);
    cell.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      PaperBridge.Notes.handleNoteClick(itemID).catch(error => {
        PaperBridge.Util.logError(error);
        PaperBridge.Util.alert(error.message);
      });
    });
    return cell;
  },

  renderRankCell(data, doc) {
    const [itemID, rank] = String(data || "").split("|");
    const cell = doc.createElement("span");
    cell.className = `paperbridge-cell paperbridge-cell-action ${rank === "x" ? "paperbridge-rank-delete" : ""} ${rank === "1" ? "paperbridge-rank-core" : ""}`;
    cell.textContent = rank || "";
    cell.title = "Set PaperBridge rank";
    cell.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      this.showRankPopup(itemID, doc, event);
    });
    return cell;
  },

  noteTitle(state) {
    switch (state) {
      case PaperBridge.Constants.noteStates.create:
        return "Create Markdown note";
      case PaperBridge.Constants.noteStates.ready:
        return "Open Markdown note";
      case PaperBridge.Constants.noteStates.missing:
        return "Markdown note missing; click to relink";
      default:
        return "PaperBridge note";
    }
  },

  showRankPopup(itemID, doc, event) {
    const popupID = "paperbridge-rank-popup";
    doc.getElementById(popupID)?.remove();

    const popup = doc.createXULElement("menupopup");
    popup.id = popupID;
    const options = [
      ["", "Clear rank"],
      ["1", "1 - Core reference"],
      ["2", "2 - Important reference"],
      ["3", "3 - Useful"],
      ["4", "4 - Low priority"],
      ["x", "x - Mark for deletion"]
    ];

    for (const [rank, label] of options) {
      const item = doc.createXULElement("menuitem");
      item.setAttribute("label", label);
      item.addEventListener("command", () => {
        PaperBridge.Ranks.setRankForItemID(itemID, rank).catch(error => {
          PaperBridge.Util.logError(error);
          PaperBridge.Util.alert(error.message);
        });
      });
      popup.appendChild(item);
    }

    doc.documentElement.appendChild(popup);
    popup.openPopupAtScreen(event.screenX, event.screenY, true);
  }
};
