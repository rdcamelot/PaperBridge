PaperBridge = PaperBridge || {};

PaperBridge.Menus = {
  addedElementIDs: new Map(),

  addToWindow(window) {
    if (this.addedElementIDs.has(window)) {
      return;
    }

    const doc = window.document;
    const ids = [];
    const toolsPopup = doc.getElementById("menu_ToolsPopup") || doc.getElementById("menu_toolsPopup");
    if (!toolsPopup) {
      this.addedElementIDs.set(window, ids);
      return;
    }

    const cleanItem = doc.createXULElement("menuitem");
    cleanItem.id = "paperbridge-clean-x-items";
    cleanItem.setAttribute("label", "PaperBridge: 清理 x");
    cleanItem.addEventListener("command", () => {
      PaperBridge.DeleteQueue.cleanRankedItems().catch(error => {
        PaperBridge.Util.logError(error);
        PaperBridge.Util.alert(error.message);
      });
    });

    toolsPopup.appendChild(cleanItem);
    ids.push(cleanItem.id);
    this.addedElementIDs.set(window, ids);
  },

  removeFromWindow(window) {
    const ids = this.addedElementIDs.get(window) || [];
    for (const id of ids) {
      window.document.getElementById(id)?.remove();
    }
    this.addedElementIDs.delete(window);
  },

  removeFromAllWindows() {
    for (const window of [...this.addedElementIDs.keys()]) {
      this.removeFromWindow(window);
    }
  }
};
