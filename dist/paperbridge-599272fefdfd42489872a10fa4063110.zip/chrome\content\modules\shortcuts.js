PaperBridge = PaperBridge || {};

PaperBridge.Shortcuts = {
  handlers: new Map(),

  addToWindow(window) {
    if (this.handlers.has(window)) {
      return;
    }
    const handler = event => this.onKeyDown(event);
    window.document.addEventListener("keydown", handler, true);
    this.handlers.set(window, handler);
  },

  removeFromWindow(window) {
    const handler = this.handlers.get(window);
    if (!handler) {
      return;
    }
    window.document.removeEventListener("keydown", handler, true);
    this.handlers.delete(window);
  },

  removeFromAllWindows() {
    for (const [window, handler] of this.handlers.entries()) {
      window.document.removeEventListener("keydown", handler, true);
    }
    this.handlers.clear();
  },

  onKeyDown(event) {
    if (event.ctrlKey || event.altKey || event.metaKey) {
      return;
    }
    if (this.isEditableTarget(event.target)) {
      return;
    }

    const key = event.key;
    if (["1", "2", "3", "4"].includes(key)) {
      this.applyRank(event, key);
      return;
    }
    if (key === "0") {
      this.applyRank(event, "");
      return;
    }
    if (key === "x" || key === "X") {
      this.applyRank(event, "x");
      return;
    }
    if (key === "m" || key === "M") {
      this.openSelectedNote(event);
    }
  },

  isEditableTarget(target) {
    const tagName = target?.tagName?.toLowerCase?.() || "";
    return tagName === "input" || tagName === "textarea" || target?.isContentEditable;
  },

  applyRank(event, rank) {
    const items = PaperBridge.Util.getSelectedRegularItems();
    if (!items.length) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    PaperBridge.Ranks.setRankForSelected(rank).catch(error => {
      PaperBridge.Util.logError(error);
      PaperBridge.Util.alert(error.message);
    });
  },

  openSelectedNote(event) {
    const [item] = PaperBridge.Util.getSelectedRegularItems();
    if (!item) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    PaperBridge.Notes.handleNoteClick(item.id).catch(error => {
      PaperBridge.Util.logError(error);
      PaperBridge.Util.alert(error.message);
    });
  }
};
