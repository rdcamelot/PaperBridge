PaperBridge = PaperBridge || {};

PaperBridge.Index = {
  all() {
    const raw = PaperBridge.Settings.getString("index", "{}");
    try {
      const parsed = JSON.parse(raw);
      return parsed && typeof parsed === "object" ? parsed : {};
    }
    catch (error) {
      PaperBridge.Util.logError(error);
      return {};
    }
  },

  save(all) {
    PaperBridge.Settings.set("index", JSON.stringify(all));
  },

  get(item) {
    if (!item?.key) {
      return null;
    }
    return this.all()[item.key] || null;
  },

  set(item, data) {
    if (!item?.key) {
      return;
    }
    const all = this.all();
    all[item.key] = Object.assign({}, all[item.key] || {}, data, {
      zotero_key: item.key,
      item_id: item.id,
      updated: PaperBridge.Util.todayISO()
    });
    this.save(all);
  },

  remove(item) {
    if (!item?.key) {
      return;
    }
    const all = this.all();
    delete all[item.key];
    this.save(all);
  }
};
