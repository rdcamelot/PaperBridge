PaperBridge = PaperBridge || {};

PaperBridge.Settings = {
  key(name) {
    return PaperBridge.Constants.prefBranch + name;
  },

  get(name, fallback = undefined) {
    const value = Zotero.Prefs.get(this.key(name), true);
    return value === undefined || value === null ? fallback : value;
  },

  getString(name, fallback = "") {
    const value = this.get(name, fallback);
    return typeof value === "string" ? value : String(value ?? fallback);
  },

  getBool(name, fallback = false) {
    const value = this.get(name, fallback);
    return Boolean(value);
  },

  getInt(name, fallback = 0) {
    const value = Number.parseInt(this.get(name, fallback), 10);
    return Number.isFinite(value) ? value : fallback;
  },

  set(name, value) {
    Zotero.Prefs.set(this.key(name), value, true);
  },

  markdownRoot() {
    return this.getString("markdownRoot", "D:\\学\\论文").trim();
  },

  editorPath() {
    return this.getString("markdownEditorPath", "").trim();
  },

  filenameTemplate() {
    return this.getString("filenameTemplate", "{{citekey}} - {{shortTitle}}.md");
  },

  maxFilenameLength() {
    return this.getInt("maxFilenameLength", 180);
  },

  rankTagPrefix() {
    return this.getString("rankTagPrefix", "paperbridge/rank/");
  },

  statusTagPrefix() {
    return this.getString("statusTagPrefix", "paperbridge/status/");
  },

  noteAttachmentTitle() {
    return this.getString("noteAttachmentTitle", PaperBridge.Constants.noteAttachmentTitle);
  }
};
