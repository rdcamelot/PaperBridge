PaperBridge = Object.assign(PaperBridge || {}, {
  id: null,
  version: null,
  rootURI: null,
  initialized: false,

  init({ id, version, rootURI }) {
    if (this.initialized) {
      return;
    }
    this.id = id;
    this.version = version;
    this.rootURI = rootURI;
    this.initialized = true;
  },

  async start() {
    await this.Columns.register();
    this.Notifications.start();
  },

  async stop() {
    this.Notifications.stop();
    this.Menus.removeFromAllWindows();
    this.Shortcuts.removeFromAllWindows();
    await this.Columns.unregister().catch(error => this.Util.logError(error));
  },

  addToWindow(window) {
    if (!window?.ZoteroPane) {
      return;
    }
    this.UI.addToWindow(window);
    this.Menus.addToWindow(window);
    this.Shortcuts.addToWindow(window);
  },

  addToAllWindows() {
    for (const window of Zotero.getMainWindows()) {
      this.addToWindow(window);
    }
  },

  removeFromWindow(window) {
    this.Shortcuts.removeFromWindow(window);
    this.Menus.removeFromWindow(window);
    this.UI.removeFromWindow(window);
  },

  removeFromAllWindows() {
    for (const window of Zotero.getMainWindows()) {
      this.removeFromWindow(window);
    }
  }
});
