PaperBridge = PaperBridge || {};

PaperBridge.Constants = Object.freeze({
  addonID: "paperbridge@zotero.local",
  prefBranch: "extensions.paperbridge.",
  noteAttachmentTitle: "Markdown Reading Note",
  rankValues: ["1", "2", "3", "4", "x"],
  emptyRank: "",
  noteStates: Object.freeze({
    create: "+",
    ready: "M",
    missing: "!"
  }),
  markdownContentType: "text/markdown",
  unfiledDirectoryName: "Unfiled",
  statusUnread: "unread"
});
