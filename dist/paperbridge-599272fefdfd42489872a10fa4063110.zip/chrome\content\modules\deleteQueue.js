PaperBridge = PaperBridge || {};

PaperBridge.DeleteQueue = {
  async cleanRankedItems() {
    const items = await this.findDeleteRankedItems();
    if (!items.length) {
      PaperBridge.Util.alert("No items are marked with rank x.");
      return;
    }

    const ok = PaperBridge.Util.confirm(
      `Clean ${items.length} item(s) marked x?\n\nZotero items will be moved to Zotero Trash. Markdown notes will be deleted to the Windows Recycle Bin. No .trash folder will be used.`
    );
    if (!ok) {
      return;
    }

    let moved = 0;
    for (const item of items) {
      await this.cleanItem(item);
      moved++;
    }
    Zotero.ItemTreeManager.refreshColumns();
    PaperBridge.Util.alert(`Cleaned ${moved} item(s).`);
  },

  async findDeleteRankedItems() {
    const search = new Zotero.Search();
    search.libraryID = Zotero.Libraries.userLibraryID;
    search.addCondition("tag", "is", PaperBridge.Ranks.rankTag("x"));
    const ids = await search.search();
    return ids
      .map(id => Zotero.Items.get(id))
      .filter(item => item && PaperBridge.Notes.isRegularItem(item) && !item.deleted);
  },

  async cleanItem(item) {
    const path = PaperBridge.Notes.getNotePath(item);
    if (path && PaperBridge.Util.pathExistsSync(path)) {
      await this.sendFileToRecycleBin(path);
    }
    item.deleted = true;
    await item.saveTx();
    PaperBridge.Index.remove(item);
  },

  async sendFileToRecycleBin(path) {
    if (!Zotero.isWin) {
      throw new Error("PaperBridge currently implements recycle-bin deletion only on Windows.");
    }

    const powershell = "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe";
    if (!PaperBridge.Util.pathExistsSync(powershell)) {
      throw new Error("PowerShell was not found; cannot send file to Recycle Bin.");
    }

    const escaped = String(path).replace(/'/g, "''");
    const command = [
      "Add-Type -AssemblyName Microsoft.VisualBasic;",
      `[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile('${escaped}',`,
      "[Microsoft.VisualBasic.FileIO.UIOption]::OnlyErrorDialogs,",
      "[Microsoft.VisualBasic.FileIO.RecycleOption]::SendToRecycleBin)"
    ].join(" ");
    PaperBridge.Util.runProcess(
      powershell,
      ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
      true
    );
  }
};
