PaperBridge = PaperBridge || {};

PaperBridge.Notifications = {
  observerID: null,
  timers: new Map(),

  start() {
    if (this.observerID) {
      return;
    }
    this.observerID = Zotero.Notifier.registerObserver(this.observer, ["item", "collection-item"]);
  },

  stop() {
    if (this.observerID) {
      Zotero.Notifier.unregisterObserver(this.observerID);
      this.observerID = null;
    }
    for (const timer of this.timers.values()) {
      clearTimeout(timer);
    }
    this.timers.clear();
  },

  observer: {
    notify: (event, type, ids, extraData) => {
      PaperBridge.Notifications.notify(event, type, ids, extraData);
    }
  },

  notify(event, type, ids, extraData) {
    if (!PaperBridge.Settings.getBool("autoCreate", true)) {
      return;
    }

    if (type === "item" && (event === "add" || event === "modify")) {
      for (const id of ids) {
        this.scheduleItem(id);
      }
    }

    if (type === "collection-item" && event === "add") {
      for (const id of this.extractItemIDs(ids, extraData)) {
        this.scheduleItem(id);
      }
    }
  },

  scheduleItem(itemID) {
    const numericID = Number(itemID);
    if (!Number.isFinite(numericID)) {
      return;
    }
    clearTimeout(this.timers.get(numericID));
    const timer = setTimeout(() => {
      this.timers.delete(numericID);
      this.tryAutoCreate(numericID).catch(error => PaperBridge.Util.logError(error));
    }, 3000);
    this.timers.set(numericID, timer);
  },

  async tryAutoCreate(itemID) {
    const item = Zotero.Items.get(itemID);
    if (!item || !PaperBridge.Notes.isRegularItem(item) || item.deleted) {
      return;
    }
    const collectionIDs = typeof item.getCollections === "function" ? item.getCollections() : [];
    if (!collectionIDs.length) {
      return;
    }
    const state = PaperBridge.Notes.getNoteState(item);
    if (state !== PaperBridge.Constants.noteStates.create) {
      return;
    }
    await PaperBridge.Notes.createNoteForItem(item);
  },

  extractItemIDs(ids, extraData) {
    const found = new Set();
    for (const value of Object.values(extraData || {})) {
      const itemID = value?.itemID || value?.item?.id || value?.id;
      if (Number.isFinite(Number(itemID))) {
        found.add(Number(itemID));
      }
    }

    for (const id of ids || []) {
      const itemID = this.itemIDFromCollectionItemNotifierID(id);
      if (itemID && Zotero.Items.get(itemID)) {
        found.add(itemID);
      }
    }
    return [...found];
  },

  itemIDFromCollectionItemNotifierID(id) {
    const match = String(id).match(/(?:^|[-:])(\d+)$/);
    return match ? Number(match[1]) : null;
  }
};
