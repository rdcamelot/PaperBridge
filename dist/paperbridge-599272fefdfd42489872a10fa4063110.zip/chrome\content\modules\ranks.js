PaperBridge = PaperBridge || {};

PaperBridge.Ranks = {
  rankTag(rank) {
    return PaperBridge.Settings.rankTagPrefix() + rank;
  },

  statusTag(status) {
    return PaperBridge.Settings.statusTagPrefix() + status;
  },

  getRank(item) {
    if (!item?.getTags) {
      return "";
    }
    const prefix = PaperBridge.Settings.rankTagPrefix();
    const tag = item.getTags().map(entry => entry.tag).find(name => name.startsWith(prefix));
    return tag ? tag.slice(prefix.length) : "";
  },

  async setRankForItemID(itemID, rank) {
    const item = Zotero.Items.get(Number(itemID));
    if (!item || !PaperBridge.Notes.isRegularItem(item)) {
      return;
    }
    await this.setRank(item, rank);
  },

  async setRankForSelected(rank) {
    const items = PaperBridge.Util.getSelectedRegularItems();
    for (const item of items) {
      await this.setRank(item, rank);
    }
  },

  async setRank(item, rank) {
    const normalized = PaperBridge.Constants.rankValues.includes(rank) ? rank : "";
    const prefix = PaperBridge.Settings.rankTagPrefix();
    const existing = item.getTags ? item.getTags() : [];

    for (const tag of existing) {
      if (tag.tag?.startsWith(prefix)) {
        this.removeTag(item, tag.tag);
      }
    }

    if (normalized) {
      item.addTag(this.rankTag(normalized), 0);
    }

    await item.saveTx();
    PaperBridge.Index.set(item, { rank: normalized });
    Zotero.ItemTreeManager.refreshColumns();
  },

  async ensureUnreadStatus(item) {
    const tag = this.statusTag(PaperBridge.Constants.statusUnread);
    const tags = item.getTags ? item.getTags().map(entry => entry.tag) : [];
    if (!tags.includes(tag)) {
      item.addTag(tag, 0);
      await item.saveTx({ skipDateModifiedUpdate: true });
    }
  },

  removeTag(item, tagName) {
    if (typeof item.removeTag === "function") {
      item.removeTag(tagName);
      return;
    }

    if (typeof item.setTags === "function") {
      const remaining = item.getTags().filter(tag => tag.tag !== tagName);
      item.setTags(remaining);
    }
  }
};
