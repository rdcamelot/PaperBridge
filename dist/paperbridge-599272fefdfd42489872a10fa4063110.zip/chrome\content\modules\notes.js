PaperBridge = PaperBridge || {};

PaperBridge.Notes = {
  isRegularItem(item) {
    return Boolean(item && typeof item.isRegularItem === "function" && item.isRegularItem());
  },

  getNoteAttachment(item) {
    if (!item || typeof item.getAttachments !== "function") {
      return null;
    }
    const title = PaperBridge.Settings.noteAttachmentTitle();
    for (const attachmentID of item.getAttachments()) {
      const attachment = Zotero.Items.get(attachmentID);
      if (!attachment?.isAttachment?.()) {
        continue;
      }
      const path = this.getAttachmentPath(attachment);
      const attachmentTitle = attachment.getField("title") || "";
      if (attachmentTitle === title || path?.toLowerCase().endsWith(".md")) {
        return attachment;
      }
    }
    return null;
  },

  getAttachmentPath(attachment) {
    if (!attachment) {
      return "";
    }
    if (typeof attachment.getFilePath === "function") {
      return attachment.getFilePath() || "";
    }
    const path = attachment.attachmentPath || "";
    if (path.startsWith(Zotero.Attachments.BASE_PATH_PLACEHOLDER)) {
      const resolved = Zotero.Attachments.resolveRelativePath(path);
      return resolved || "";
    }
    return path;
  },

  getNotePath(item) {
    const attachment = this.getNoteAttachment(item);
    const attachmentPath = this.getAttachmentPath(attachment);
    if (attachmentPath) {
      return attachmentPath;
    }
    return PaperBridge.Index.get(item)?.note_path || "";
  },

  getNoteState(item) {
    if (!this.isRegularItem(item)) {
      return "";
    }
    const path = this.getNotePath(item);
    if (!path) {
      return PaperBridge.Constants.noteStates.create;
    }
    return PaperBridge.Util.pathExistsSync(path)
      ? PaperBridge.Constants.noteStates.ready
      : PaperBridge.Constants.noteStates.missing;
  },

  getNoteCellData(item) {
    return `${item.id}|${this.getNoteState(item)}`;
  },

  async handleNoteClick(itemID) {
    const item = Zotero.Items.get(Number(itemID));
    if (!item || !this.isRegularItem(item)) {
      return;
    }

    const state = this.getNoteState(item);
    if (state === PaperBridge.Constants.noteStates.ready) {
      await this.openNote(item);
      return;
    }

    if (state === PaperBridge.Constants.noteStates.missing) {
      const recreate = PaperBridge.Util.confirm("The linked Markdown note is missing. Create a new note and relink it?");
      if (!recreate) {
        return;
      }
    }

    const path = await this.createNoteForItem(item);
    await this.openPath(path);
  },

  async createNoteForItem(item, options = {}) {
    if (!this.isRegularItem(item)) {
      throw new Error("PaperBridge can create notes only for regular Zotero items.");
    }

    const existingPath = this.getNotePath(item);
    if (existingPath && PaperBridge.Util.pathExistsSync(existingPath)) {
      return existingPath;
    }

    const collection = options.collection || this.pickPrimaryCollection(item);
    const directory = this.directoryForCollection(collection);
    await PaperBridge.Util.ensureDirectory(directory);

    const filename = await this.filenameForItem(item);
    const path = await PaperBridge.Util.uniquePath(directory, filename);
    const content = await this.renderMarkdown(item, collection);
    await Zotero.File.putContentsAsync(path, content);

    if (PaperBridge.Settings.getBool("attachLinkedNote", true)) {
      await this.attachMarkdownNote(item, path);
    }

    PaperBridge.Index.set(item, {
      note_path: path,
      primary_collection: collection?.name || PaperBridge.Constants.unfiledDirectoryName,
      citekey: this.citekeyForItem(item),
      rank: PaperBridge.Ranks.getRank(item)
    });

    await PaperBridge.Ranks.ensureUnreadStatus(item);
    Zotero.ItemTreeManager.refreshColumns();
    return path;
  },

  async openNote(item) {
    const path = this.getNotePath(item);
    if (!path || !PaperBridge.Util.pathExistsSync(path)) {
      throw new Error("Markdown note file is missing.");
    }
    await this.openPath(path);
  },

  async openPath(path) {
    const editorPath = PaperBridge.Settings.editorPath();
    if (editorPath && PaperBridge.Util.pathExistsSync(editorPath)) {
      PaperBridge.Util.runProcess(editorPath, [path], false);
      return;
    }

    const file = Zotero.File.pathToFile(path);
    file.launch();
  },

  async attachMarkdownNote(item, path) {
    const existing = this.getNoteAttachment(item);
    if (existing) {
      existing.setField("title", PaperBridge.Settings.noteAttachmentTitle());
      existing.attachmentPath = path;
      existing.attachmentContentType = PaperBridge.Constants.markdownContentType;
      await existing.saveTx();
      return existing;
    }

    return Zotero.Attachments.linkFromFile({
      file: path,
      parentItemID: item.id,
      title: PaperBridge.Settings.noteAttachmentTitle(),
      contentType: PaperBridge.Constants.markdownContentType
    });
  },

  pickPrimaryCollection(item) {
    const selected = PaperBridge.Util.getSelectedCollection();
    const collectionIDs = typeof item.getCollections === "function" ? item.getCollections() : [];
    if (selected && collectionIDs.includes(selected.id)) {
      return selected;
    }
    if (collectionIDs.length) {
      return Zotero.Collections.get(collectionIDs[0]);
    }
    return null;
  },

  directoryForCollection(collection) {
    const root = PaperBridge.Settings.markdownRoot();
    const collectionName = collection?.name || PaperBridge.Constants.unfiledDirectoryName;
    return PaperBridge.Util.pathJoin(root, PaperBridge.Util.sanitizePathSegment(collectionName));
  },

  async filenameForItem(item) {
    const template = PaperBridge.Settings.filenameTemplate();
    const data = {
      citekey: this.citekeyForItem(item),
      shortTitle: this.shortTitle(item),
      title: item.getField("title") || "Untitled"
    };

    let filename = template.replace(/{{\s*(citekey|shortTitle|title)\s*}}/g, (_, key) => data[key] || "");
    filename = PaperBridge.Util.sanitizePathSegment(filename, `${data.citekey}.md`);
    if (!filename.toLowerCase().endsWith(".md")) {
      filename += ".md";
    }
    return PaperBridge.Util.truncateFilename(filename, PaperBridge.Settings.maxFilenameLength());
  },

  async renderMarkdown(item, collection) {
    const pdfAttachment = this.bestPDFAttachment(item);
    const collectionName = collection?.name || PaperBridge.Constants.unfiledDirectoryName;
    const rank = PaperBridge.Ranks.getRank(item);
    const date = PaperBridge.Util.todayISO();
    const citekey = this.citekeyForItem(item);

    const lines = [
      "---",
      `title: ${PaperBridge.Util.yamlString(item.getField("title") || "Untitled")}`,
      `citekey: ${PaperBridge.Util.yamlString(citekey)}`,
      `zotero_key: ${PaperBridge.Util.yamlString(item.key)}`,
      `collection: ${PaperBridge.Util.yamlString(collectionName)}`,
      `primary_collection: ${PaperBridge.Util.yamlString(collectionName)}`,
      `rank: ${rank ? PaperBridge.Util.yamlString(rank) : ""}`,
      "status: unread",
      `doi: ${PaperBridge.Util.yamlString(item.getField("DOI") || "")}`,
      `url: ${PaperBridge.Util.yamlString(item.getField("url") || "")}`,
      `pdf: ${PaperBridge.Util.yamlString(PaperBridge.Util.zoteroPDFURI(pdfAttachment))}`,
      `zotero: ${PaperBridge.Util.yamlString(PaperBridge.Util.zoteroSelectURI(item))}`,
      `created: ${PaperBridge.Util.yamlString(date)}`,
      `updated: ${PaperBridge.Util.yamlString(date)}`,
      "---",
      "",
      "## 一句话总结",
      "",
      "## 研究问题",
      "",
      "## 核心方法",
      "",
      "## 关键结论",
      "",
      "## 可复用点",
      "",
      "## 局限性",
      "",
      "## 和我的研究的关系",
      "",
      "## 后续引用价值",
      ""
    ];
    return lines.join("\n");
  },

  bestPDFAttachment(item) {
    if (!item || typeof item.getAttachments !== "function") {
      return null;
    }
    for (const attachmentID of item.getAttachments()) {
      const attachment = Zotero.Items.get(attachmentID);
      const contentType = attachment?.attachmentContentType || "";
      const path = this.getAttachmentPath(attachment);
      if (contentType === "application/pdf" || path.toLowerCase().endsWith(".pdf")) {
        return attachment;
      }
    }
    return null;
  },

  citekeyForItem(item) {
    const fromBetterBibTeX = this.citekeyFromBetterBibTeX(item);
    if (fromBetterBibTeX) {
      return fromBetterBibTeX;
    }

    const extra = item.getField("extra") || "";
    const pinned = extra.match(/^Citation Key:\s*(.+)$/mi);
    if (pinned?.[1]) {
      return PaperBridge.Util.sanitizePathSegment(pinned[1], "citekey").replace(/\s+/g, "_");
    }

    return this.fallbackCitekey(item);
  },

  citekeyFromBetterBibTeX(item) {
    try {
      if (Zotero.BetterBibTeX?.KeyManager?.get) {
        return Zotero.BetterBibTeX.KeyManager.get(item.id);
      }
      if (Zotero.BetterBibTeX?.getCitationKey) {
        return Zotero.BetterBibTeX.getCitationKey(item.id);
      }
    }
    catch (error) {
      PaperBridge.Util.logError(error);
    }
    return "";
  },

  fallbackCitekey(item) {
    const creator = PaperBridge.Util.sanitizePathSegment(item.firstCreator || "unknown", "unknown")
      .split(/\s+/)[0]
      .toLowerCase();
    const year = this.yearForItem(item) || "nd";
    const titleWord = PaperBridge.Util.sanitizePathSegment(item.getField("title") || "paper", "paper")
      .split(/\s+/)[0]
      .toLowerCase();
    return `${creator}${year}_${titleWord}`.replace(/[^a-z0-9_\-]/gi, "");
  },

  yearForItem(item) {
    const date = item.getField("date") || "";
    const match = String(date).match(/(18|19|20)\d{2}/);
    return match ? match[0] : "";
  },

  shortTitle(item) {
    const title = item.getField("title") || "Untitled";
    const clean = PaperBridge.Util.sanitizePathSegment(title, "Untitled");
    return clean.length > 90 ? clean.slice(0, 90).trim() : clean;
  }
};
